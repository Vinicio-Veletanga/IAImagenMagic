
// Librerías propias de C++ que contienen funciones de impresión, lectura desde teclado, etc.
#include <iostream>
#include <cstdlib>

// Cargamos las librerías principales para desarrollar proyectos
// usando OpenCV

// #include <opencv2/opencv.hpp> // Con esta librería se cargan automáticamente las demás librerías que están instaladas en OpenCV

#include <opencv2/core/core.hpp> // Contiene las principales estructuras para representar una imagen como una Matriz
#include <opencv2/imgproc/imgproc.hpp> // Contienen métodos para procesar imágenes
#include <opencv2/imgcodecs/imgcodecs.hpp> // Con esta librería se pueden leer archivos .jpeg, .png, etc.
#include <opencv2/highgui/highgui.hpp> // Librería para crear ventanas y componentes gráficos básicos
#include <opencv2/video/video.hpp> // Librería para acceder a la cámara y leer videos guardado en disco
#include <opencv2/videoio/videoio.hpp> // Libreria para almacenar videos en disco

using namespace std; 
using namespace cv;


int main(int argc, char *argv[]){

    Mat imagen = imread("San-Basilio.jpg");
    // Para cargar la imagen existe un segundo parámetro que indica en qué espacio de color se carga
    // Mat imagen = imread("San-Basilio.jpg", IMREAD_GRAYSCALE); // Escala de grises
    // Mat imagen = imread("San-Basilio.jpg", IMREAD_UNCHANGED); // Sin cambios
    namedWindow("San Basilio", WINDOW_AUTOSIZE);
    imshow("San Basilio", imagen);

    // Cómo obtener las propiedades de la imagen
    cout << "Ancho (columnas) = " << imagen.cols << " Alto imagen (filas) = " << imagen.rows << " Canales: " << imagen.channels() << endl;

    // Cómo creamos una imagen desde cero y guardamos la conversión de la imagen a colores en escala de grises
    // Crear imagenes vacias
    //Mat gris = Mat::zeros(Size(imagen.cols, imagen.rows), CV_8UC1);
    Mat gris = Mat(Size(imagen.cols, imagen.rows), CV_8UC1, Scalar(123));

    Mat grisPesos = Mat(Size(imagen.cols, imagen.rows), CV_8UC1, Scalar(123));

    // Manipulación de pixeles
    int blanco = 255;
    gris.at<uchar>(imagen.rows/2, imagen.cols/2) = blanco;

    // Conversión de una imagen a colores en escala de grises
    // OpenCV manejas imágenes a color como BGR (intercambia el orden de los canales)
    Vec3b pixel = imagen.at<Vec3b>(imagen.rows/2, imagen.cols/2);

    cout << "Rojo: " << (int)pixel[2] << " Verde: " << (int)pixel[1] << " Azul: " << (int)pixel[0] << endl;


    int valor = 0;
    for(int i=0;i<imagen.rows;i++){
        for(int j=0;j<imagen.cols;j++){
            pixel = imagen.at<Vec3b>(i,j);
            valor = (pixel[0]+pixel[1]+pixel[2])/3;

            gris.at<uchar>(i,j) = valor;
            grisPesos.at<uchar>(i,j) = (0.114*pixel[0]+0.587*pixel[1]+0.299*pixel[2]);
        }
    }

    Mat gris3;
    cvtColor(imagen, gris3, COLOR_BGR2GRAY);


    namedWindow("Gris", WINDOW_AUTOSIZE);
    namedWindow("Gris Pesos", WINDOW_AUTOSIZE);
    namedWindow("Gris CvtColor", WINDOW_AUTOSIZE);
    imshow("Gris", gris);
    imshow("Gris CvtColor", gris3);
    imshow("Gris Pesos", grisPesos);

    waitKey(0);

    destroyAllWindows();  // Elimina de memoria las ventanas que ya no se utilizarán

    return 0;
}